const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');

// Determine persistent writable file path
const isServerless = Boolean(
  process.env.NETLIFY ||
  process.env.AWS_LAMBDA_FUNCTION_NAME ||
  process.env.LAMBDA_TASK_ROOT ||
  process.env.RENDER
);

const STORAGE_PATH = isServerless
  ? path.join(process.platform === 'win32' ? os.tmpdir() : '/tmp', 'toji_data.json')
  : path.join(__dirname, 'toji_data.json');

// Default initial database structure
function getInitialData() {
  const seedPaths = [
    path.join(__dirname, 'toji_data.json'),
    path.join(__dirname, '..', 'toji_data.json'),
    path.join(__dirname, '..', '..', 'toji_data.json'),
    path.join(process.cwd(), 'toji_data.json')
  ];

  for (const p of seedPaths) {
    if (fs.existsSync(p)) {
      try {
        const raw = fs.readFileSync(p, 'utf8');
        return JSON.parse(raw);
      } catch (err) {
        console.warn('Failed to parse seed data from', p, err.message);
      }
    }
  }

  return {
    users: [],
    sessions: [],
    tasks: [],
    time_logs: [],
    daily_summaries: [],
    settings: [
      { key: 'daily_goal_hours', value: '8.0' },
      { key: 'pomodoro_length', value: '25' },
      { key: 'short_break', value: '5' },
      { key: 'long_break', value: '15' },
      { key: 'sound_enabled', value: 'true' },
      { key: 'theme', value: 'dark' }
    ]
  };
}

let store = null;

function loadStore() {
  if (store) return store;

  if (fs.existsSync(STORAGE_PATH)) {
    try {
      const raw = fs.readFileSync(STORAGE_PATH, 'utf8');
      store = JSON.parse(raw);
      return store;
    } catch (err) {
      console.warn('Could not read store from', STORAGE_PATH, err.message);
    }
  }

  store = getInitialData();
  persistStore();
  return store;
}

function persistStore() {
  if (!store) return;
  try {
    fs.writeFileSync(STORAGE_PATH, JSON.stringify(store), 'utf8');
  } catch (err) {
    console.warn('Failed to persist store to', STORAGE_PATH, err.message);
  }
}

// -----------------------------------------------------------------------------
// Database Query APIs (100% compatible with SQLite db.js)
// -----------------------------------------------------------------------------
const dbApi = {
  getUserCount() {
    const data = loadStore();
    return (data.users || []).length;
  },

  getOwner() {
    const data = loadStore();
    return (data.users && data.users[0]) ? { ...data.users[0] } : null;
  },

  createOwner(username, passwordHash, passwordSalt) {
    const data = loadStore();
    const now = new Date().toISOString();
    const newId = (data.users || []).reduce((max, u) => Math.max(max, Number(u.id) || 0), 0) + 1;
    const user = {
      id: newId,
      username,
      password_hash: passwordHash,
      password_salt: passwordSalt,
      created_at: now,
      last_login_at: now
    };
    data.users = [user]; // Single owner
    persistStore();
    return { id: user.id, username, created_at: now };
  },

  updateOwnerPassword(userId, passwordHash, passwordSalt) {
    const data = loadStore();
    const user = (data.users || []).find(u => Number(u.id) === Number(userId));
    if (user) {
      user.password_hash = passwordHash;
      user.password_salt = passwordSalt;
      persistStore();
    }
  },

  updateLastLogin(userId) {
    const data = loadStore();
    const user = (data.users || []).find(u => Number(u.id) === Number(userId));
    if (user) {
      user.last_login_at = new Date().toISOString();
      persistStore();
    }
  },

  // Sessions
  createSession(token, userId, expiresAt, ipAddress = '', userAgent = '') {
    const data = loadStore();
    const now = new Date().toISOString();
    data.sessions = (data.sessions || []).filter(s => s.token !== token);
    data.sessions.push({
      token,
      user_id: userId,
      created_at: now,
      expires_at: expiresAt,
      last_activity_at: now,
      ip_address: ipAddress,
      user_agent: userAgent
    });
    persistStore();
  },

  getSession(token) {
    const data = loadStore();
    const now = new Date().toISOString();
    const session = (data.sessions || []).find(s => s.token === token && s.expires_at > now);
    if (!session) return null;
    const user = (data.users || []).find(u => Number(u.id) === Number(session.user_id));
    return {
      token: session.token,
      user_id: session.user_id,
      expires_at: session.expires_at,
      username: user ? user.username : 'Owner'
    };
  },

  touchSession(token) {
    const data = loadStore();
    const session = (data.sessions || []).find(s => s.token === token);
    if (session) {
      session.last_activity_at = new Date().toISOString();
      persistStore();
    }
  },

  deleteSession(token) {
    const data = loadStore();
    data.sessions = (data.sessions || []).filter(s => s.token !== token);
    persistStore();
  },

  deleteUserSessions(userId) {
    const data = loadStore();
    data.sessions = (data.sessions || []).filter(s => Number(s.user_id) !== Number(userId));
    persistStore();
  },

  cleanupExpiredSessions() {
    const data = loadStore();
    const now = new Date().toISOString();
    data.sessions = (data.sessions || []).filter(s => s.expires_at > now);
    persistStore();
  },

  // Tasks
  getTasks({ date, status, category, search } = {}) {
    const data = loadStore();
    let tasks = [...(data.tasks || [])];

    if (date) {
      tasks = tasks.filter(t => t.date === date);
    }
    if (status && status !== 'all') {
      tasks = tasks.filter(t => t.status === status);
    }
    if (category && category !== 'all') {
      tasks = tasks.filter(t => t.category === category);
    }
    if (search) {
      const q = search.toLowerCase();
      tasks = tasks.filter(t =>
        (t.title && t.title.toLowerCase().includes(q)) ||
        (t.notes && t.notes.toLowerCase().includes(q))
      );
    }

    tasks.sort((a, b) => {
      const orderA = a.sort_order !== undefined ? a.sort_order : 0;
      const orderB = b.sort_order !== undefined ? b.sort_order : 0;
      if (orderA !== orderB) return orderA - orderB;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

    return tasks;
  },

  getTaskById(id) {
    const data = loadStore();
    return (data.tasks || []).find(t => t.id === id) || null;
  },

  createTask({ id, title, notes = '', category = 'Engineering', priority = 'Medium', plannedMins = 45, date }) {
    const data = loadStore();
    const taskId = id || 'task_' + crypto.randomBytes(8).toString('hex');
    const taskDate = date || new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();

    const tasksOnDate = (data.tasks || []).filter(t => t.date === taskDate);
    const maxOrder = tasksOnDate.reduce((max, t) => Math.max(max, t.sort_order !== undefined ? t.sort_order : 0), -1);
    const nextOrder = maxOrder + 1;

    const newTask = {
      id: taskId,
      title: title.trim(),
      notes: notes.trim(),
      category,
      priority,
      status: 'active',
      planned_mins: Number(plannedMins) || 45,
      actual_mins: 0,
      date: taskDate,
      sort_order: nextOrder,
      created_at: now,
      completed_at: null
    };

    data.tasks = data.tasks || [];
    data.tasks.push(newTask);
    persistStore();
    return newTask;
  },

  updateTask(id, fields) {
    const data = loadStore();
    const task = (data.tasks || []).find(t => t.id === id);
    if (!task) return null;

    const allowed = ['title', 'notes', 'category', 'priority', 'status', 'planned_mins', 'actual_mins', 'date', 'sort_order', 'completed_at'];
    for (const key of allowed) {
      if (fields[key] !== undefined) {
        task[key] = fields[key];
      }
    }

    persistStore();
    return task;
  },

  deleteTask(id) {
    const data = loadStore();
    data.tasks = (data.tasks || []).filter(t => t.id !== id);
    persistStore();
  },

  reorderTasks(taskIds) {
    const data = loadStore();
    const map = new Map();
    taskIds.forEach((id, idx) => map.set(id, idx));

    (data.tasks || []).forEach(t => {
      if (map.has(t.id)) {
        t.sort_order = map.get(t.id);
      }
    });

    persistStore();
  },

  // Time Logs
  addTimeLog({ taskId = null, durationSeconds, type = 'focus', startedAt, endedAt, notes = '' }) {
    const data = loadStore();
    const id = 'log_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    const start = startedAt || new Date(Date.now() - durationSeconds * 1000).toISOString();
    const end = endedAt || now;

    const log = {
      id,
      task_id: taskId,
      duration_seconds: Number(durationSeconds) || 0,
      type: type || 'focus',
      started_at: start,
      ended_at: end,
      notes: notes || '',
      created_at: now
    };

    data.time_logs = data.time_logs || [];
    data.time_logs.push(log);

    if (taskId) {
      const addedMins = Math.round(Number(durationSeconds) / 60);
      if (addedMins > 0) {
        const task = (data.tasks || []).find(t => t.id === taskId);
        if (task) {
          task.actual_mins = (task.actual_mins || 0) + addedMins;
        }
      }
    }

    persistStore();
    return log;
  },

  getTimeLogs({ taskId, date } = {}) {
    const data = loadStore();
    const taskMap = new Map((data.tasks || []).map(t => [t.id, t]));

    let logs = (data.time_logs || []).map(tl => {
      const parentTask = tl.task_id ? taskMap.get(tl.task_id) : null;
      return {
        ...tl,
        task_title: parentTask ? parentTask.title : null,
        task_category: parentTask ? parentTask.category : null
      };
    });

    if (taskId) {
      logs = logs.filter(l => l.task_id === taskId);
    }
    if (date) {
      logs = logs.filter(l => l.started_at && l.started_at.startsWith(date));
    }

    logs.sort((a, b) => new Date(b.started_at).getTime() - new Date(a.started_at).getTime());
    return logs;
  },

  // Daily Standup & Journal
  getDailySummary(date) {
    const data = loadStore();
    return (data.daily_summaries || []).find(s => s.date === date) || null;
  },

  saveDailySummary(date, params = {}) {
    const data = loadStore();
    data.daily_summaries = data.daily_summaries || [];
    let summary = data.daily_summaries.find(s => s.date === date);
    const now = new Date().toISOString();

    const summaryText = params.summary_text !== undefined ? params.summary_text : (params.summaryText || '');
    const mood = params.mood || 'productive';
    const blockers = params.blockers || '';
    const goalsTomorrow = params.goals_tomorrow !== undefined ? params.goals_tomorrow : (params.goalsTomorrow || '');

    if (summary) {
      summary.summary_text = summaryText;
      summary.mood = mood;
      summary.blockers = blockers;
      summary.goals_tomorrow = goalsTomorrow;
      summary.updated_at = now;
    } else {
      summary = {
        date,
        summary_text: summaryText,
        mood,
        blockers,
        goals_tomorrow: goalsTomorrow,
        created_at: now,
        updated_at: now
      };
      data.daily_summaries.push(summary);
    }

    persistStore();
    return summary;
  },

  generateDailyStandup(date) {
    const tasks = this.getTasks({ date });
    const completedTasks = tasks.filter(t => t.status === 'completed');
    const inProgressTasks = tasks.filter(t => t.status === 'active');

    const logs = (loadStore().time_logs || []).filter(l => l.started_at && l.started_at.startsWith(date));
    const totalSeconds = logs.reduce((sum, l) => sum + (Number(l.duration_seconds) || 0), 0);
    const focusSeconds = logs.reduce((sum, l) => sum + (l.type === 'focus' ? (Number(l.duration_seconds) || 0) : 0), 0);

    const totalHours = (totalSeconds / 3600).toFixed(1);
    const focusHours = (focusSeconds / 3600).toFixed(1);
    const existingJournal = this.getDailySummary(date) || {};

    let markdown = `# 📋 Daily Standup — ${date}\n\n`;
    markdown += `**⏱️ Total Time Tracked:** ${totalHours}h (${focusHours}h Deep Focus)\n`;
    markdown += `**✅ Tasks Completed:** ${completedTasks.length}/${tasks.length}\n\n`;

    markdown += `### 🎯 Accomplished Today\n`;
    if (completedTasks.length === 0) {
      markdown += `- No tasks marked completed yet for today.\n`;
    } else {
      for (const t of completedTasks) {
        markdown += `- [x] **[${t.category}]** ${t.title} (${t.actual_mins}m logged / ${t.planned_mins}m planned)\n`;
        if (t.notes) markdown += `  - *Notes:* ${t.notes}\n`;
      }
    }

    markdown += `\n### ⏳ In Progress & Carry-over\n`;
    if (inProgressTasks.length === 0) {
      markdown += `- All planned tasks for today completed!\n`;
    } else {
      for (const t of inProgressTasks) {
        markdown += `- [ ] **[${t.category}]** ${t.title} (${t.actual_mins}m logged so far)\n`;
      }
    }

    if (existingJournal.blockers) {
      markdown += `\n### 🛑 Blockers & Obstacles\n${existingJournal.blockers}\n`;
    }

    if (existingJournal.goals_tomorrow) {
      markdown += `\n### 🚀 Goals for Tomorrow\n${existingJournal.goals_tomorrow}\n`;
    }

    return {
      date,
      markdown,
      totalHours,
      focusHours,
      completedCount: completedTasks.length,
      activeCount: inProgressTasks.length,
      mood: existingJournal.mood || 'productive'
    };
  },

  // Analytics & Dashboard Telemetry
  getAnalytics(range = '30d') {
    const data = loadStore();
    const now = new Date();
    let startDate;

    if (range === 'today') {
      startDate = now.toISOString().split('T')[0];
    } else if (range === '7d') {
      const d = new Date(now);
      d.setDate(now.getDate() - 6);
      startDate = d.toISOString().split('T')[0];
    } else if (range === '30d') {
      const d = new Date(now);
      d.setDate(now.getDate() - 29);
      startDate = d.toISOString().split('T')[0];
    } else {
      startDate = '1970-01-01';
    }

    const filteredLogs = (data.time_logs || []).filter(l => (l.started_at || '') >= startDate);
    const totalDuration = filteredLogs.reduce((sum, l) => sum + (Number(l.duration_seconds) || 0), 0);
    const focusDuration = filteredLogs.reduce((sum, l) => sum + (l.type === 'focus' ? (Number(l.duration_seconds) || 0) : 0), 0);

    const totalHours = (totalDuration / 3600).toFixed(1);
    const focusHours = (focusDuration / 3600).toFixed(1);

    const filteredTasks = (data.tasks || []).filter(t => (t.date || '') >= startDate);
    const totalTasks = filteredTasks.length;
    const completedTasks = filteredTasks.filter(t => t.status === 'completed').length;
    const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 100;

    const deepFocusScore = totalTasks > 0
      ? Math.min(100, Math.round((completionRate * 0.5) + (Number(focusHours) > 0 ? 50 : 20)))
      : 85;

    // Consecutive active streak (up to 90 days back)
    const ninetyDaysAgo = new Date(now);
    ninetyDaysAgo.setDate(now.getDate() - 90);
    const ninetyStr = ninetyDaysAgo.toISOString().split('T')[0];

    const datesWithActivity = new Set();
    (data.tasks || []).forEach(t => {
      if (t.date >= ninetyStr) datesWithActivity.add(t.date);
    });
    (data.time_logs || []).forEach(l => {
      if (l.started_at && l.started_at >= ninetyStr) datesWithActivity.add(l.started_at.slice(0, 10));
    });

    let streak = 0;
    const checkDate = new Date();
    const todayStr = checkDate.toISOString().split('T')[0];
    checkDate.setDate(checkDate.getDate() - 1);
    const yesterdayStr = checkDate.toISOString().split('T')[0];

    const hasToday = datesWithActivity.has(todayStr);
    const hasYesterday = datesWithActivity.has(yesterdayStr);

    if (hasToday || hasYesterday) {
      let cur = new Date();
      if (!hasToday && hasYesterday) {
        cur.setDate(cur.getDate() - 1);
      }
      while (true) {
        const s = cur.toISOString().split('T')[0];
        if (datesWithActivity.has(s)) {
          streak++;
          cur.setDate(cur.getDate() - 1);
        } else {
          break;
        }
      }
    }

    // Category breakdown
    const categoryMap = new Map();
    filteredTasks.forEach(t => {
      const cat = t.category || 'Engineering';
      const current = categoryMap.get(cat) || { category: cat, total_mins: 0, task_count: 0 };
      current.total_mins += Number(t.actual_mins) || 0;
      current.task_count += 1;
      categoryMap.set(cat, current);
    });
    const categories = Array.from(categoryMap.values());

    // 90-day activity heatmap
    const heatmap = [];
    for (let i = 89; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const dayTasks = (data.tasks || []).filter(t => t.date === dStr);
      const dayLogs = (data.time_logs || []).filter(l => l.started_at && l.started_at.startsWith(dStr));
      const totalMins = Math.round(dayLogs.reduce((s, l) => s + (Number(l.duration_seconds) || 0), 0) / 60);

      heatmap.push({
        date: dStr,
        task_count: dayTasks.length,
        completed_count: dayTasks.filter(t => t.status === 'completed').length,
        total_mins: totalMins
      });
    }

    // Workload series (planned vs actual for 7 or 14 days)
    const daysBack = range === 'today' ? 1 : (range === '7d' ? 7 : 14);
    const workload = [];
    for (let i = daysBack - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const dayTasks = (data.tasks || []).filter(t => t.date === dStr);
      const plannedHours = Number((dayTasks.reduce((s, t) => s + (Number(t.planned_mins) || 0), 0) / 60).toFixed(1));
      const actualHours = Number((dayTasks.reduce((s, t) => s + (Number(t.actual_mins) || 0), 0) / 60).toFixed(1));

      workload.push({
        date: dStr,
        planned_hours: plannedHours,
        actual_hours: actualHours
      });
    }

    return {
      totalHours: Number(totalHours),
      focusHours: Number(focusHours),
      totalTasks,
      completedTasks,
      completionRate,
      deepFocusScore,
      streak,
      categories,
      heatmap,
      workload
    };
  },

  // Settings
  getSettings() {
    const data = loadStore();
    const map = {};
    (data.settings || []).forEach(r => { map[r.key] = r.value; });
    return map;
  },

  updateSettings(settingsObj) {
    const data = loadStore();
    data.settings = data.settings || [];
    for (const [k, v] of Object.entries(settingsObj)) {
      const existing = data.settings.find(s => s.key === k);
      if (existing) {
        existing.value = String(v);
      } else {
        data.settings.push({ key: k, value: String(v) });
      }
    }
    persistStore();
    return this.getSettings();
  },

  // Classes (be10x & nxtwave)
  getClasses(platform) {
    const data = loadStore();
    let cls = data.classes || [];
    if (platform && platform !== 'all') {
      cls = cls.filter(c => c.platform === platform);
    }
    return cls.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  },
  createClass({ platform, title, module = '', status = 'pending', notes = '', date }) {
    const data = loadStore();
    const id = 'cls_' + crypto.randomBytes(8).toString('hex');
    const classDate = date || new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();
    const cls = { id, platform, title, module, status, notes, date: classDate, created_at: now };
    data.classes = data.classes || [];
    data.classes.push(cls);
    persistStore();
    return cls;
  },
  updateClass(id, fields) {
    const data = loadStore();
    const cls = (data.classes || []).find(c => c.id === id);
    if (!cls) return null;
    Object.assign(cls, fields);
    persistStore();
    return cls;
  },
  deleteClass(id) {
    const data = loadStore();
    data.classes = (data.classes || []).filter(c => c.id !== id);
    persistStore();
  },

  // Workouts
  getWorkouts(date) {
    const data = loadStore();
    let wrks = data.workouts || [];
    if (date) {
      wrks = wrks.filter(w => w.date === date);
    }
    return wrks.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  },
  createWorkout({ exercise, category = 'Push', sets = 3, reps = '12', weight = 'Bodyweight', status = 'pending', date }) {
    const data = loadStore();
    const id = 'wrk_' + crypto.randomBytes(8).toString('hex');
    const wDate = date || new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();
    const wrk = { id, exercise, category, sets, reps, weight, status, date: wDate, created_at: now };
    data.workouts = data.workouts || [];
    data.workouts.push(wrk);
    persistStore();
    return wrk;
  },
  updateWorkout(id, fields) {
    const data = loadStore();
    const wrk = (data.workouts || []).find(w => w.id === id);
    if (!wrk) return null;
    Object.assign(wrk, fields);
    persistStore();
    return wrk;
  },
  deleteWorkout(id) {
    const data = loadStore();
    data.workouts = (data.workouts || []).filter(w => w.id !== id);
    persistStore();
  },

  // BTech Subjects
  getBTechSubjects(semester) {
    const data = loadStore();
    let subjects = data.btech_subjects || [];
    if (semester && semester !== 'all') {
      subjects = subjects.filter(s => String(s.semester) === String(semester));
    }
    return subjects.sort((a, b) => (a.semester || 5) - (b.semester || 5) || a.code.localeCompare(b.code));
  },
  createBTechSubject({ subject_name, code, credits = 3, internal_marks = 0, external_marks = 0, grade = 'A', status = 'ongoing', semester = 5 }) {
    const data = loadStore();
    const id = 'sub_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    const sub = { id, subject_name, code, credits, internal_marks, external_marks, grade, status, semester: parseInt(semester) || 5, created_at: now };
    data.btech_subjects = data.btech_subjects || [];
    data.btech_subjects.push(sub);
    persistStore();
    return sub;
  },
  updateBTechSubject(id, fields) {
    const data = loadStore();
    const sub = (data.btech_subjects || []).find(s => s.id === id);
    if (!sub) return null;
    Object.assign(sub, fields);
    persistStore();
    return sub;
  },
  deleteBTechSubject(id) {
    const data = loadStore();
    data.btech_subjects = (data.btech_subjects || []).filter(s => s.id !== id);
    persistStore();
  },

  // Coding Practice
  getCodingPractice() {
    const data = loadStore();
    return (data.coding_practice || []).sort((a, b) => new Date(b.date) - new Date(a.date));
  },
  createCodingPractice({ platform = 'LeetCode', problem_title, difficulty = 'Medium', status = 'solved', date, notes = '' }) {
    const data = loadStore();
    const id = 'cod_' + crypto.randomBytes(8).toString('hex');
    const cDate = date || new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();
    const cod = { id, platform, problem_title, difficulty, status, date: cDate, notes, created_at: now };
    data.coding_practice = data.coding_practice || [];
    data.coding_practice.push(cod);
    persistStore();
    return cod;
  },
  deleteCodingPractice(id) {
    const data = loadStore();
    data.coding_practice = (data.coding_practice || []).filter(c => c.id !== id);
    persistStore();
  },

  // Subject Works
  getSubjectWorks(subjectId) {
    const data = loadStore();
    return (data.subject_works || []).filter(w => w.subject_id === subjectId).sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
  },
  createSubjectWork({ subjectId, title, type = 'Assignment', status = 'pending', deadline = '' }) {
    const data = loadStore();
    const id = 'work_' + crypto.randomBytes(8).toString('hex');
    const now = new Date().toISOString();
    const work = { id, subject_id: subjectId, title, type, status, deadline, created_at: now };
    data.subject_works = data.subject_works || [];
    data.subject_works.push(work);
    persistStore();
    return work;
  },
  updateSubjectWork(id, fields) {
    const data = loadStore();
    const work = (data.subject_works || []).find(w => w.id === id);
    if (!work) return null;
    Object.assign(work, fields);
    persistStore();
    return work;
  },
  deleteSubjectWork(id) {
    const data = loadStore();
    data.subject_works = (data.subject_works || []).filter(w => w.id !== id);
    persistStore();
  },

  // Clear & Seed Data
  clearWorkData() {
    const data = loadStore();
    data.time_logs = [];
    data.tasks = [];
    data.daily_summaries = [];
    data.classes = [];
    data.workouts = [];
    data.btech_subjects = [];
    data.coding_practice = [];
    data.subject_works = [];
    persistStore();
  },

  seedSampleData() {
    this.clearWorkData();
    const data = loadStore();
    const categories = ['Engineering', 'Product', 'Design', 'Deep Work', 'Admin'];
    const priorities = ['High', 'Medium', 'Low'];
    const sampleTitles = {
      'Engineering': [
        'Implement Redis cache layer for API gateway',
        'Refactor authentication middleware to scrypt v2',
        'Fix memory leak in distributed worker queue',
        'Write integration tests for payment webhooks',
        'Database schema migration for parcel audit logs',
        'Optimize SQLite query latency and WAL configuration'
      ],
      'Product': [
        'Draft Q4 product roadmap specs',
        'Review user churn analytics & teardown',
        'Synthesize customer feedback interviews',
        'Define KPI telemetry for checkout funnel',
        'Prioritize sprint backlog with engineering leads'
      ],
      'Design': [
        'Create high-fidelity dark mode tokens in Figma',
        'Design mobile responsive drawer navigation',
        'Accessibility audit: contrast ratios & focus rings',
        'Micro-animations for task completion states'
      ],
      'Deep Work': [
        'Write RFC for event-driven telemetry architecture',
        'Deep profile Node.js garbage collection pauses',
        'Competitive teardown of workflow automation engines',
        'Draft system design document for offline sync'
      ],
      'Admin': [
        'Weekly engineering team sync & standup',
        'Inbox zero & triage GitHub security dependabot PRs',
        'Update documentation for developer onboarding',
        'Review cloud infrastructure billing alerts'
      ]
    };

    const estimates = [15, 25, 30, 45, 60, 90, 120];
    const now = new Date();

    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const isWeekend = (d.getDay() === 0 || d.getDay() === 6);
      const taskCount = isWeekend ? Math.floor(Math.random() * 2) + 1 : Math.floor(Math.random() * 3) + 3;

      for (let j = 0; j < taskCount; j++) {
        const cat = categories[Math.floor(Math.random() * categories.length)];
        const titles = sampleTitles[cat];
        const title = titles[Math.floor(Math.random() * titles.length)];
        const priority = priorities[Math.floor(Math.random() * priorities.length)];
        const planned = estimates[Math.floor(Math.random() * estimates.length)];
        const isPast = i > 0;
        const isCompleted = isPast ? Math.random() > 0.15 : Math.random() > 0.5;
        const variance = (Math.random() * 0.4) - 0.2;
        const actual = isCompleted ? Math.max(15, Math.round(planned * (1 + variance))) : Math.floor(planned * 0.4);

        const taskId = 'task_' + crypto.randomBytes(8).toString('hex');
        const createdIso = new Date(d.getTime() + j * 3600000).toISOString();
        const completedIso = isCompleted ? new Date(d.getTime() + (j + 1) * 3600000).toISOString() : null;

        data.tasks.push({
          id: taskId,
          title,
          notes: isCompleted ? 'Accomplished during deep work session.' : '',
          category: cat,
          priority,
          status: isCompleted ? 'completed' : 'active',
          planned_mins: planned,
          actual_mins: actual,
          date: dateStr,
          sort_order: j,
          created_at: createdIso,
          completed_at: completedIso
        });

        if (actual > 0) {
          const logId = 'log_' + crypto.randomBytes(8).toString('hex');
          const logDurationSec = actual * 60;
          data.time_logs.push({
            id: logId,
            task_id: taskId,
            duration_seconds: logDurationSec,
            type: 'focus',
            started_at: createdIso,
            ended_at: new Date(new Date(createdIso).getTime() + logDurationSec * 1000).toISOString(),
            notes: 'Focus session',
            created_at: createdIso
          });
        }
      }
    }

    persistStore();
  }
};

module.exports = dbApi;
